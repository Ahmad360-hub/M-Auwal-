
M AUWAL STORE - SIMPLE FULL STACK APP

HOW TO RUN BACKEND:
1. cd backend
2. npm install
3. node server.js

HOW TO RUN FRONTEND:
1. open frontend/index.html in browser


const express = require('express');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

let users = [];
let products = [
  {id:1, name:"Rice", price:500},
  {id:2, name:"Milk", price:300},
  {id:3, name:"Sugar", price:200}
];

app.get('/api/products', (req,res)=>{
  res.json(products);
});

app.post('/api/login', (req,res)=>{
  const user = req.body;
  users.push(user);
  res.json({message:"Login successful", user});
});

app.listen(5000, ()=> console.log("Server running on port 5000"));
